package apis

import "github.com/gin-gonic/gin"

func Send(c *gin.Context) {

}
