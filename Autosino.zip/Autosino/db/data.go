package db

type User struct {
	Id     int
	Name   string
	Passwd string
}
