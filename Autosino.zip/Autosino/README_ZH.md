Autosino 自动化运维工具
开始
    go mod download
   // go mod vendor
目录结构
    api 存放handler
    cmd 存放操作指令
    db 存放数据库操作
    router 注册路由信息