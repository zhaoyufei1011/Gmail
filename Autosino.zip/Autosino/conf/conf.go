package conf

import (
	"io/ioutil"

	"gopkg.in/yaml.v2"
)

type Database struct {
	Ip       string
	Port     string
	Username string
	Password string
	Database string
}

func (conf *Database) Getconf() *Database {
	yamlFile, err := ioutil.ReadFile("./db.yaml")
	if err != nil {
		panic(err)
	}
	err = yaml.Unmarshal(yamlFile, &conf)
	if err != nil {
		panic(err)
	}
	return conf
}
